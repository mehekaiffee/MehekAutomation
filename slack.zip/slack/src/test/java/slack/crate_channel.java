package slack;

import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.testng.Assert.assertNotEquals;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.expect;

public class crate_channel {
	

	  
	  @Test
	    public void test1() {
	        //RestAssured.baseURI = "https://slack.com";

	        Response getResponse = expect().statusCode(200).given()
	            .config(RestAssured.config().encoderConfig(
	                EncoderConfig.encoderConfig().defaultContentCharset("UTF-8")
	               .encodeContentTypeAs("x-www-form-urlencoded", ContentType.URLENC)))
	            .contentType("application/x-www-form-urlencoded")
	            .formParam("token",
	                "hXNHENcvfIBD049JCmvJ1kS3n6sH+WzVLGsaFbqyQAW/sEGlHEmcOJC5ladCAm3Jzzi4xKuR25mLIvxfA6VKuLUhKWstKwENDSc9KzZB+iedRadE9l2BtKbNuy675O95")
	            .formParam("name", "me@109").when().log().all().then().log().all().request()
	            .post("https://slack.com/api/channels.create");

	        System.out.println(getResponse.body().asString());

	    }
	  @Test
	  public void test2_invalid_auth() {
	        //RestAssured.baseURI = "https://slack.com";

	        Response getResponse = expect().statusCode(200).given()
	            .config(RestAssured.config().encoderConfig(
	                EncoderConfig.encoderConfig().defaultContentCharset("UTF-8")
	               .encodeContentTypeAs("x-www-form-urlencoded", ContentType.URLENC)))
	            .contentType("application/x-www-form-urlencoded")
	            .formParam("token",
	                "0hXNHENcvfIBD049JCmvJ1kS3n6sH+WzVLGsaFbqyQAW/sEGlHEmcOJC5ladCAm3Jzzi4xKuR25mLIvxfA6VKuLUhKWstKwENDSc9KzZB+iedRadE9l2BtKbNuy675O95")
	            .formParam("name", "me@109").when().log().all().then().log().all().request()
	            .post("https://slack.com/api/channels.create");

	        System.out.println(getResponse.body().asString());
	  
}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		        
	
	


